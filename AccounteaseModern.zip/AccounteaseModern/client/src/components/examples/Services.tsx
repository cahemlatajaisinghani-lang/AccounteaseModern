import Services from "../Services";

export default function ServicesExample() {
  return <Services />;
}
